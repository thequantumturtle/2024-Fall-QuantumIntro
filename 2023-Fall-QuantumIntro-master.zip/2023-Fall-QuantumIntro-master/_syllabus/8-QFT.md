---
week: 8
day: September 25
title: QFT
---

### Summary
QFT is faster than the FFT! We will be showing how to encode signals into a quantum state and then perform a Fourier transform on the state. We will also be going over how to do a reverse QFT!

### Notes
- Reminder to bring your computer to class.