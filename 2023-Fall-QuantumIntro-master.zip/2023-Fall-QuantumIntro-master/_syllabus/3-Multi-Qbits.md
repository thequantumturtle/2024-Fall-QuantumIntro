---
week: 3
day: September 06
title: Two Qbits Are Better Than One
---

### Before Class
Read Chapter 3 in the [Octopus](https://www.amazon.com/Programming-Quantum-Computers-Essential-Algorithms/dp/1492039683) Book

### Summary
We will now start to incorporate more qubits and multi qubit gates. This is where the state explosion starts to happen.

### Notes

- Reminder to bring computer to class.