---
week: 10
day: October 02
title: Real Data
---

### Summary

Lets take a look at what a quantum computer might be able to do applicable data.

### Notes
- Reminder to bring your computer to class.