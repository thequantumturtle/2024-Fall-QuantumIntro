---
week: 13
day : October 11
title: Shor's Algorithm
---

### Summary
The algorithm that started it all! Well, not really. But it is probably what put quantum computers on the radar.


### Notes
- Reminder to bring your computer to class.