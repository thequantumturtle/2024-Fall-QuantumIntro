---
week: 4
day: September 11
title: Quantum Teleportation
---

### Before Class
Read Chapter 4 in the [Octopus](https://www.amazon.com/Programming-Quantum-Computers-Essential-Algorithms/dp/1492039683) Book

### Summary
We will go over teleporting a quantum state from one qubit to another. This will require knowledge of the No Cloning Theorem, No Signalling Theorem and Entanglement.

### Notes
- Reminder to bring computer to class.