---
week: 7
day: September 20
title: Amplitude Amplification
--- 

### Summary
We will learn about Amplitude Amplification - One of the first quantum primitives. While not amazingly useful by themselves, they help to make the building blochs of more impressive algorithms.

### Notes
- Reminder to bring your computer to class.
