---
week: 6
day: September 18
title: Quantum Arithmetic
---

### Summary
Lets get some real compute in on a quantum simulator. We will get a little bit of classical and "quantum" math in.

### Notes
- Reminder to bring your comptuer to class.