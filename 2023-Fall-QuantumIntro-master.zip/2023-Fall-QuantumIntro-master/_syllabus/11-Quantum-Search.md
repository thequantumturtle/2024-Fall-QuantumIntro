---
week: 11
day : October 04
title: Quantum Search
---

### Summary
Finally, lets take a look at a quantum simulator that has advantage over classical computer.

### Notes
- Reminder to bring your computer to class.
