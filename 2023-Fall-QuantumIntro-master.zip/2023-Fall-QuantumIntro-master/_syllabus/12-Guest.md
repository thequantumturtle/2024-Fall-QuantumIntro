---
week: 12
day : October 09
title: Guest Lecture
---

### Summary
TBD