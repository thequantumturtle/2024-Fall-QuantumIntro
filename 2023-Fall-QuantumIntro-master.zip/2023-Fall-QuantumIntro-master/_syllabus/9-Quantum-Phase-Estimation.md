---
week: 9
day : September 27
title: Quantum Phase Estimation
---

### Summary

The final primitive we will learn for the semester.

### Notes
- Reminder to bring your computer to class.